<?php
defined('JPATH_BASE') or die;

$d = $displayData;
?>
<div id="<?php echo $d->id; ?>" class="modal fade fabrikEventModal" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content" >
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><!-- Modal Header--></h4>
      </div>
      <div class="modal-body">
        <!-- modal body will go here -->
      </div>
      <div class="modal-footer">
        <div class="btn-group calEventButtons">
        </div>
      </div>
    </div>

  </div>
</div>
