<?
    phpinfo();
?>
